// pages/PostDetail.tsx
import { useState } from 'react';

export default function PostDetail() {
  const [comment, setComment] = useState('');
  const [isLiked, setIsLiked] = useState(false);
  const [likes, setLikes] = useState(1400);

  const comments = [
    {
      id: 1,
      username: "@JeanetteGottlieb",
      time: "1 hours ago",
      text: "This sunflower is so vibrant! The colors just pop. It makes me feel so cheerful!"
    },
    {
      id: 2,
      username: "@FernandoPidrillo",
      time: "2 hours ago", 
      text: "I love how the light hits it! It really brings out the texture of the petals. Such a warm feeling."
    },
    {
      id: 3,
      username: "@AngelaMayer",
      time: "3 hours ago",
      text: "Definitely gives off those Van Gogh vibes! It's like a little piece of art in nature."
    },
    {
      id: 4,
      username: "@Tobuj-lalvorson",
      time: "4 hours ago",
      text: "The contrast with the background is stunning. It makes"
    }
  ];

  const handleLike = () => {
    setIsLiked(!isLiked);
    setLikes(isLiked ? likes - 1 : likes + 1);
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (comment.trim()) {
      // Aquí iría la lógica para agregar el comentario
      console.log('Nuevo comentario:', comment);
      setComment('');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#131230] to-[#702A4C] text-white">
      {/* Header con botón de volver */}
      <header className="p-4 border-b border-white/10 flex items-center sticky top-0 bg-[#131230]/80 backdrop-blur-sm z-10">
        <button 
          onClick={() => window.history.back()}
          className="text-2xl mr-4 hover:text-[#C72C8D] transition-colors"
        >
          ←
        </button>
        <h1 className="text-xl font-bold">Publication</h1>
      </header>

      {/* Contenido principal */}
      <div className="p-4 pb-24"> {/* pb-24 para espacio del input de comentarios */}
        
        {/* Título principal */}
        <h1 className="text-2xl font-bold leading-tight mb-4">
          HOLLOW KNIGHT: SILKSONG SHATTERS RECORDS WITH AN ESTIMATED 5 MILLION PLAYERS IN ITS FIRST 3 DAYS
        </h1>

        {/* Estadísticas */}
        <div className="flex space-x-6 text-gray-300 text-sm mb-6">
          <span className="font-semibold">24 COMMENTS</span>
          <span className="font-semibold">{likes.toLocaleString()} LIKES</span>
        </div>

        {/* Imagen de la publicación */}
        <div className="bg-gray-800 h-80 rounded-xl mb-6 overflow-hidden border border-white/10">
          <img 
            src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=600" 
            alt="Game content"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Acciones - Like y Comment */}
        <div className="flex items-center space-x-8 mb-8">
          <button 
            onClick={handleLike}
            className="flex items-center space-x-3 transition-transform active:scale-95"
          >
            <span className={`text-3xl transition-colors ${isLiked ? 'text-red-500' : 'text-gray-400'}`}>
              {isLiked ? '❤️' : '🤍'}
            </span>
            <span className="font-semibold">Like</span>
          </button>
          <button className="flex items-center space-x-3 text-gray-400 transition-transform active:scale-95">
            <span className="text-3xl">💬</span>
            <span className="font-semibold">Comment</span>
          </button>
        </div>

        {/* Línea divisoria */}
        <div className="border-t border-white/10 mb-6"></div>

        {/* Sección de comentarios */}
        <div className="space-y-6">
          {comments.map((commentItem) => (
            <div key={commentItem.id} className="pb-6">
              {/* Header del comentario */}
              <div className="flex justify-between items-start mb-3">
                <span className="font-bold text-[#C72C8D] text-lg">
                  {commentItem.username}
                </span>
                <span className="text-gray-400 text-sm">
                  {commentItem.time}
                </span>
              </div>
              
              {/* Texto del comentario */}
              <p className="text-gray-200 leading-relaxed text-base">
                {commentItem.text}
              </p>
            </div>
          ))}
        </div>

        {/* Línea divisoria final */}
        <div className="border-t border-white/20 mt-6 pt-4">
          <div className="text-center text-gray-400 text-sm">
            ---
          </div>
        </div>
      </div>

      {/* Input para comentar - FIXED en la parte inferior */}
      <form 
        onSubmit={handleCommentSubmit} 
        className="fixed bottom-0 left-0 right-0 bg-[#1B1E54] border-t border-white/10 p-4"
      >
        <div className="flex items-center space-x-3">
          <div className="flex-1 relative">
            <input
              type="text"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Message"
              className="w-full bg-[#2B1A40] border border-white/20 rounded-full px-6 py-4 text-white placeholder-gray-400 focus:outline-none focus:border-[#C72C8D] transition-colors text-base"
            />
          </div>
          <button 
            type="submit"
            disabled={!comment.trim()}
            className="bg-[#C72C8D] text-white rounded-full px-8 py-4 font-semibold hover:bg-[#A51C6F] disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-95 text-base"
          >
            Send
          </button>
        </div>
      </form>
    </div>
  );
}